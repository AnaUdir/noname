from __future__ import print_function
import argparse
import imutils
import os
import re
import cv2 # opencv library
import numpy as np
from os.path import isfile, join
import matplotlib.pyplot as plt
import time
from PIL import Image
import PIL
import glob

images = [cv2.imread(file) for file in glob.glob('')] # naložimo vhodne slike


#backSub = cv2.createBackgroundSubtractorMOG2(detectShadows=False) #  MOG2 algoritem
#backSub = cv2.createBackgroundSubtractorKNN(detectShadows=False)  #  KNN algoritem
backSub = cv2.bgsegm.createBackgroundSubtractorGMG()  #  GMG algoritem

for i in range(len(images)):
    img = images[i]
    fgMask = backSub.apply(img)
    cv2.imwrite("" % i,fgMask)




