Proces validacije je sledeč:
1. Pridobite dataset iz spletne strani CDnet, http://changedetection.net/
2. Zaženete algoritem in shranite 8-bit binarne izhode
	2.1 Ne pozabite upoštevati ROI, kjer potrebno
3. Z validacija.py primerjate izhod algoritma in groundtruth
	3.1 Pazite, gt ima posebne vrednosti 50, 85, 170

calculations.m vsebuje funkcijo za preračun povprečja različnih kategorij