clc
clear
close all


%GF

%cameraJitter/sidewalk

true_positives1=  295.7875
true_negatives1=  24173.2275
false_positives1=  322.3775
false_negatives1=  361.4375
recall1=  0.45005515614895963
specificity1=  0.9868393738386948
false_positive_rate1 = 0.013160626161305262
false_negative_rate1=  0.01475519792223952
percentage_of_wrong_classifications1=  2.7186404074611086
precision1=  0.47849279723051297
F_measure1=  0.4638385121413842

%intermittentObjectMotion/sofa

true_positives2=  1404.1613333333332
true_negatives2=  70135.08488888889
false_positives2=  1755.5426666666667
false_negatives2=  1879.1137777777778
recall2=  0.4276709339955808
specificity2=  0.9755803680346229
false_positive_rate2=  0.024419631965377137
false_negative_rate2=  0.026138508477000548
percentage_of_wrong_classifications2=  4.834997672744361
precision2=  0.44439647933266324
F_measure2=  0.43587331547042113

%shadow/bungalows

true_positives3=  1919.4264285714285
true_negatives3=  54948.78357142857
false_positives3=  1497.1314285714286
false_negatives3=  9603.158571428572
recall3=  0.1665794983132195
specificity3=  0.9734767090130185
false_positive_rate3=  0.026523290986981588
false_negative_rate3=  0.17013026667082237
percentage_of_wrong_classifications3=  16.331521219388392
precision3=  0.5618012364574956
F_measure3=  0.25696607187254955

%PTZ/twoPositionPTZCam

true_positives4=  1314.8518024032044
true_negatives4=  91688.12416555407
false_positives4=  2321.8130841121497
false_negatives4=  22903.248331108145
recall4=  0.054292111897902444
specificity4=  0.975302471716942
false_positive_rate4=  0.02469752828305811
false_negative_rate4=  0.24362582298382998
percentage_of_wrong_classifications4=  21.33593855869041
precision4=  0.3615542931323246
F_measure4=  0.0944076750572383

%baseline/highway

true_positives5=  3834.8520325203253
true_negatives5=  67249.88536585365
false_positives5=  2844.758536585366
false_negatives5=  602.3227642276423
recall5=  0.8642553444887751
specificity5=  0.959415464888518
false_positive_rate5=  0.04058453511148203
false_negative_rate5=  0.008592992712338808
percentage_of_wrong_classifications5=  4.624979453038103
precision5=  0.5741131152551248
F_measure5=  0.6899210349602439

%GMG

%bungalows
recall6=  0.23529727347608548
specificity6=  0.9795815656442641
false_positive_rate6=  0.020418434355735867
false_negative_rate6=  0.19674987646628775
percentage_of_wrong_classifications6=  17.272739070413305
precision6=  0.7477895376187653
F_measure6=  0.3579599224603202

%highway
recall7=  0.9956996733987147
specificity7=  0.9896910040949121
false_positive_rate7=  0.010308995905087852;
false_negative_rate7=  0.0002710845008620533
percentage_of_wrong_classifications7=  0.9952682048672423
precision7=  0.8589278068227026
F_measure7=  0.9222705323274256

%sidewalk
recall8=  0.7847845106318233
specificity8=  0.8936831939221497
false_positive_rate8=  0.10631680607785043
false_negative_rate8=  0.00576874567048388
percentage_of_wrong_classifications8=  10.915958265710533
precision8=  0.16517738122211345
F_measure8=  0.2729133692654983

%sofa
recall9=  0.36489702896931236
specificity9=  0.9942742343072357
false_positive_rate9=  0.005725765692764203
false_negative_rate9=  0.029005419046681233
percentage_of_wrong_classifications9=  3.3214274875924588
precision9=  0.7442800446408603
F_measure9=  0.48970643817336523

%2posPTZ
recall10=  0.9122073750218089
specificity10=  0.9785543145596276
false_positive_rate10=  0.021445685440372425
false_negative_rate10=  0.001455140572439495
percentage_of_wrong_classifications10=  2.252743939783033
precision10=  0.4134961276643751
F_measure10=  0.569047628574744

%KNN

%bungalows
recall11=  0.46572000152972287
specificity11=  0.978583825492592
false_positive_rate11=  0.02141617450740797
false_negative_rate11=  0.06727831354617178
percentage_of_wrong_classifications11=  7.877489180183224
precision11=  0.7325024052340863
F_measure11=  0.5694118543610064

%highway
recall12=  0.9268383804607231
specificity12=  0.9866019921649996
false_positive_rate12=  0.013398007835000439
false_negative_rate12=  0.00461197089289367
percentage_of_wrong_classifications12=  1.6941987688607798
precision12=  0.813460978090198
F_measure12=  0.8664565114003107

%sidewalk
recall13=  0.7355662063981132
specificity13=  0.9076234966115323
false_positive_rate13=  0.09237650338846769
false_negative_rate13=  0.007088018183304957
percentage_of_wrong_classifications13=  9.686802174415584
precision13=  0.17589405587917467
F_measure13=  0.28389986654549565

%sofa
recall14=  0.4671898750421158
specificity14=  0.9937283557012211
false_positive_rate14=  0.0062716442987790005
false_negative_rate14=  0.02433366186531551
percentage_of_wrong_classifications14=  2.926859706117515
precision14=  0.7728356629443498
F_measure14=  0.5823444529785198

%2posPTZ
recall15=  0.8238960614359421
specificity15=  0.9756311336093797
false_positive_rate15=  0.024368866390620282
false_negative_rate15=  0.0027182441522063624
percentage_of_wrong_classifications15=  2.6675364199533025
precision15=  0.34291062304749387
F_measure15=  0.4842665293410665

%MOG2

%bungalows
recall16=  0.8568812784974338
specificity16=  0.9753549454863972
false_positive_rate16=  0.024645054513602764
false_negative_rate16=  0.010166798211062245
percentage_of_wrong_classifications16=  3.2502925680113783
precision16=  0.7118069056888823
F_measure16=  0.77763575647300

%highway
recall17=  0.9109192932952832
specificity17=  0.9727857380214897
false_positive_rate17=  0.027214261978510283
false_negative_rate17=  0.005615480207077603
percentage_of_wrong_classifications17=  3.0882939748670872
precision17=  0.6784586667481837
F_measure17=  0.7776892655884239

%sidewalk
recall18=  0.6098292061318422
specificity18=  0.9304036082750679
false_positive_rate18=  0.06959639172493225
false_negative_rate18=  0.01045833682549529
percentage_of_wrong_classifications18=  7.796491717249712
precision18=  0.19019880246340895
F_measure18=  0.289961810005001

%sofa
recall19=  0.46634288878760494
specificity19=  0.9884862568269756
false_positive_rate19=  0.011513743173024466
false_negative_rate19=  0.02437234408278175
percentage_of_wrong_classifications19=  3.431873618126376
precision19=  0.6490976817448715
F_measure19=  0.5427489298972518

%2posPTZ
recall20=  0.7960122107792087
specificity20=  0.985402821229961
false_positive_rate20=  0.014597178770038998
false_negative_rate20=  0.003148644031997188
percentage_of_wrong_classifications20=  1.7476071710057495
precision20=  0.45703075566729373
F_measure20=  0.5806697327299464



%Re, Sp, FPR, FNR, PWC, Pr, F_Meas

GF = [recall1 specificity1 false_positive_rate1 false_negative_rate1 percentage_of_wrong_classifications1 precision1 F_measure1;
    recall2 specificity2 false_positive_rate2 false_negative_rate2 percentage_of_wrong_classifications2 precision2 F_measure2;
    recall3 specificity3 false_positive_rate3 false_negative_rate3 percentage_of_wrong_classifications3 precision3 F_measure3;
    recall4 specificity4 false_positive_rate4 false_negative_rate4 percentage_of_wrong_classifications4 precision4 F_measure4;
    recall5 specificity5 false_positive_rate5 false_negative_rate5 percentage_of_wrong_classifications5 precision5 F_measure5];

GMG = [recall6 specificity6 false_positive_rate6 false_negative_rate6 percentage_of_wrong_classifications6 precision6 F_measure6;
    recall7 specificity7 false_positive_rate7 false_negative_rate7 percentage_of_wrong_classifications7 precision7 F_measure7;
    recall8 specificity8 false_positive_rate8 false_negative_rate8 percentage_of_wrong_classifications8 precision8 F_measure8;
    recall9 specificity9 false_positive_rate9 false_negative_rate9 percentage_of_wrong_classifications9 precision9 F_measure9;
    recall10 specificity10 false_positive_rate10 false_negative_rate10 percentage_of_wrong_classifications10 precision10 F_measure10];

KNN = [recall11 specificity11 false_positive_rate11 false_negative_rate11 percentage_of_wrong_classifications11 precision11 F_measure11;
    recall12 specificity12 false_positive_rate12 false_negative_rate12 percentage_of_wrong_classifications12 precision12 F_measure12;
    recall13 specificity13 false_positive_rate13 false_negative_rate13 percentage_of_wrong_classifications13 precision13 F_measure13;
    recall14 specificity14 false_positive_rate14 false_negative_rate14 percentage_of_wrong_classifications14 precision14 F_measure14;
    recall15 specificity15 false_positive_rate15 false_negative_rate15 percentage_of_wrong_classifications15 precision15 F_measure15];

MOG2 = [recall16 specificity16 false_positive_rate16 false_negative_rate16 percentage_of_wrong_classifications16 precision16 F_measure16;
    recall17 specificity17 false_positive_rate17 false_negative_rate17 percentage_of_wrong_classifications17 precision17 F_measure17;
    recall18 specificity18 false_positive_rate18 false_negative_rate18 percentage_of_wrong_classifications18 precision18 F_measure18;
    recall19 specificity19 false_positive_rate19 false_negative_rate19 percentage_of_wrong_classifications19 precision19 F_measure19;
    recall20 specificity20 false_positive_rate20 false_negative_rate20 percentage_of_wrong_classifications20 precision20 F_measure20];

GF_a = zeros(1,7);
GMG_a = GF_a;
KNN_a = GF_a;
MOG2_a = GF_a;

[GF_a(1),GF_a(2),GF_a(3),GF_a(4),GF_a(5),GF_a(6),GF_a(7)] = averages(GF(:,1),GF(:,2),GF(:,3),GF(:,4),GF(:,5),GF(:,6),GF(:,7));
[GMG_a(1),GMG_a(2),GMG_a(3),GMG_a(4),GMG_a(5),GMG_a(6),GMG_a(7)] = averages(GMG(:,1),GMG(:,2),GMG(:,3),GMG(:,4),GMG(:,5),GMG(:,6),GMG(:,7));
[KNN_a(1),KNN_a(2),KNN_a(3),KNN_a(4),KNN_a(5),KNN_a(6),KNN_a(7)] = averages(KNN(:,1),KNN(:,2),KNN(:,3),KNN(:,4),KNN(:,5),KNN(:,6),KNN(:,7));
[MOG2_a(1),MOG2_a(2),MOG2_a(3),MOG2_a(4),MOG2_a(5),MOG2_a(6),MOG2_a(7)] = averages(MOG2(:,1),MOG2(:,2),MOG2(:,3),MOG2(:,4),MOG2(:,5),MOG2(:,6),MOG2(:,7));

GF_a
GMG_a
KNN_a
MOG2_a

f1_mat = [GF(:,7),GMG(:,7),KNN(:,7),MOG2(:,7)];

figure()
boxplot(f1_mat)
xlabel('motion detection algorythm')
ylabel('F1-measure')
set(gca,'xticklabels',{'GF','GMG','KNN','MOG2'})
title('Boxplots of average F1-measure across categories')

function [Re, Sp, FPR, FNR, PWC, Pr, F_Meas] = averages(Re, Sp, FPR, FNR, PWC, Pr, F_Meas)

    Re = mean(Re);
    Sp = mean(Sp);
    FPR = mean(FPR);
    FNR = mean(FNR);
    PWC = mean(PWC);
    F_Meas = mean(F_Meas);
    Pr = mean(Pr);
    
end


