import cv2
import numpy as np
cap = cv2.VideoCapture("--path to the video or img sequence here-- /in%06d.jpg")
ROI_mask = cv2.imread("--path to the ROI img here-- /ROI.bmp")
ROI_mask = ROI_mask[:,:,0]
ROI_mask[ROI_mask == 255] = 1

ret, frame1 = cap.read()
prvs = cv2.cvtColor(frame1,cv2.COLOR_BGR2GRAY)
save = 1;
ROI = 1;
i = 1;
cv2.imwrite('--path to the video or img sequence save file here-- /img%05d.png' %0, prvs)

while(1):
    ret, frame2 = cap.read()
    
    if frame2 is None:
        break
    
    next = cv2.cvtColor(frame2,cv2.COLOR_BGR2GRAY)

    flow = cv2.calcOpticalFlowFarneback(prvs,next, None, 0.5, 3, 9, 3, 5, 1.2, 0)

    mag, ang = cv2.cartToPolar(flow[...,0], flow[...,1])
    mag = cv2.normalize(mag,None,0,255,cv2.NORM_MINMAX)
    mag = np.round(mag).astype('uint8')
    average = sum(mag[mag != 0])/(np.size(mag[mag != 0])+1)
    th = (np.round((average*1.3))).astype('uint8')
    thresh = cv2.threshold(mag, th, 255, cv2.THRESH_BINARY)[1]
    eroded = cv2.erode(thresh, None, iterations = 2)
    contours = cv2.findContours(eroded, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)[0]

    for contour in contours:
        (x, y, w, h) = cv2.boundingRect(contour)
        
        if cv2.contourArea(contour) < 700:
            eroded[(y-1):(y+h),(x-1):(x+w)] = 0;
    dilated = cv2.dilate(eroded, None, iterations= 3 )
  
    if ROI:
        dilated = dilated*ROI_mask
    
    cv2.drawContours(frame2, contours,-1,(255,0,0),lineType=8)
    #cv2.imshow('frame2',frame2)
    #cv2.imshow('final',dilated)

    k = cv2.waitKey(30) & 0xff
    if k == 27:
        break
    if save:
        cv2.imwrite('--path to the video or img sequence save file here-- /img%05d.png' %i ,dilated)
    prvs = next
    i += 1

print('koncano')
cap.release()
cv2.destroyAllWindows()