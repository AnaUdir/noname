import os
import re
import cv2 # opencv library
import numpy as np
from os.path import isfile, join
import matplotlib.pyplot as plt
import time
import glob
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score
from sklearn.metrics import plot_confusion_matrix



gt_num_file = open('') # pot do TemporalROI.txt datoteke

gt_nums = (gt_num_file.read()).split()

start_num = int(gt_nums[0]) #  preberemo začetno GT številko
end_num = int(gt_nums[1]) #  preberemo končno GT števliko



maska = cv2.imread('') # pot do ROI.bmp datoteke
maska = (cv2.cvtColor(maska,cv2.COLOR_BGR2GRAY)).astype('uint8')
maska[maska==255] = 1


cm = np.zeros([2,2,end_num - start_num]) #  definiramo confusion matrix: velikost je 2x2xštevilo GT za validacijo
start_time = time.time() #  izmerimo začetni čas
gt = cv2.VideoCapture('')  #  pot do groundtruth datotek
input_all = cv2.VideoCapture('') #  pot do vhodnih slik
i = 0

#for i in range(len(gt)-1):
while(i<end_num):

    _, gt_curr = gt.read()
    _, input_curr = input_all.read()

    if i >= start_num:

        gt_curr = cv2.cvtColor(gt_curr,cv2.COLOR_BGR2GRAY)
        gt_curr[gt_curr == 50] = 0
        print(np.shape(gt_curr))
        input_curr = input_curr*maska
        im_pred = np.array(input_curr).flatten()
        im_actu = np.array(gt_curr).flatten()
        print(i)
        print(len(im_actu),len(im_pred))
        cm_whole = confusion_matrix(im_actu, im_pred)  # izračunamo CM za vsako sliko posebej
        print(cm_whole)
        cm[:,:,i-start_num]= ((cm_whole[[0,0,-1,-1],[0,-1,0,-1]]).reshape(2,2)) #  izločimo le TP,FP,TN in FN za vsako sliko
        print(cm[:,:,i-start_num])
    i = i+1


cm_avg = cm.mean(2) # izračunamo povprečje CM matrik za cel video
print("--- %s seconds ---" % (time.time() - start_time)) #  izmerjen čas trajanja programa

print(cm_avg)
tp = cm_avg[1][1]
tn = cm_avg[0][0]
fp = cm_avg[0][1]
fn = cm_avg[1][0]
recall = tp/(tp+fn)
specificity = tn/(tn+fp)
fpr = fp/(fp+tn)
fnr = fn/(tn+fp)
pwc = 100*(fn+fp)/(tp+fn+fp+tn)
precision = tp/(tp+fp)
f_measure = 2*(precision*recall)/(precision+recall)


print("true positives: ", tp)
print("true negatives: ", tn)
print("false positives: ", fp)
print("false negatives: ", fn)

print("recall: ",recall)
print("specificity: ", specificity)
print("false-positive rate: ",fpr)
print("false negative rate: ",fnr)
print("percentage of wrong classifications: ",pwc)
print("precision: ",precision)
print("F-measure: ",f_measure)



